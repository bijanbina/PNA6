fru tools
=========

Tools to display/manipulate FMC FRU info. Althought the primary (only)
development happens on Linux, this is known to build and run on Windows,
(as a command line utility).

The main documentation for this exists at:
http://wiki.analog.com/resources/tools-software/linux-software/fru_dump

Bugs/issues should be reported to:
http://ez.analog.com/community/linux-device-drivers

Source is at:
https://github.com/analogdevicesinc/fru_tools

Windows installer is at:
http://wiki.analog.com/resources/tools-software/linux-software/fru_dump

If you are running Linux, and have the source, you can check out the man page with:
$ man -l ./fru-dump.1
(That's a small L, not a 1, as in --local-file)

-Robin
